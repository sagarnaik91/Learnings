num1=20
num2=30

if num1>num2:
    print("Num1 is bigger than Num2")
else:
    print("Num2 is bigger than Num1")


num1=40
num2=50
num3=60

if num1>num2:
    if num1 > num3:
        print("num1 is bigger")
    else:
        print("num3 is bigger")
else:
    print("num2 is bigger")