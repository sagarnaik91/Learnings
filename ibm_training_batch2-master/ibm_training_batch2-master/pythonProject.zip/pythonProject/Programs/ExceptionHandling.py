lst=[]
try:
    print(lst[0])

except IndexError:
    print("Accessing element from list failed")

print("I am at the end of program")