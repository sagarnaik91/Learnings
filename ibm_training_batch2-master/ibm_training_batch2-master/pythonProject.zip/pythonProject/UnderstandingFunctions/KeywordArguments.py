def Function1(Str1,Str2,Str3):
    print(Str1+" "+Str2+" "+Str3)

Function1("My","name","is")
Function1(Str1="Pranoday",Str3="Dingare",Str2="P")