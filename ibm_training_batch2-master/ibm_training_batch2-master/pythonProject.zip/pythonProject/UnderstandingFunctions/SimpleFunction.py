'''
int Addition(int num1,int num2)
{
    return num1+num2
}

c=Addition(10,20)
printf(c)

'''


def ContcatenatingStrings(Str1,Str2):
    return Str1+" "+Str2

FullName=ContcatenatingStrings("Pranoday","Dingare")
print(FullName)

