num1=10
num2=20
Result=num1+num2
print("Addition is "+str(Result))

a=100
print(type(a))

name="Pranoday"
print(type(name))

marks=60.50
print(type(marks))

Name="Pranoday"
Marks=50
Address="Katraj"
Statement="My name is "+Name+" I have got "+str(Marks)+" percent marks"
print(Statement)

Statement1="My name is {} I have got {} percent marks.I stay in {} ".format(Name,Marks,Address)
print(Statement1)

Statement2="My name is {2} I have got {0} percent marks.I stay in {1} ".format(Marks,Address,Name)
print(Statement2)


